# scala-sbt-sample

Simple Scala 3 + sbt sample project.

## Build & Run
- sbt compile
- sbt run
- sbt test
