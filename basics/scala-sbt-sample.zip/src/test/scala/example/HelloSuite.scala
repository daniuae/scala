package example

import org.scalatest.funsuite.AnyFunSuite

class HelloSuite extends AnyFunSuite:
  test("Greeter.greet should include the name") {
    assert(Greeter.greet("Dani").contains("Dani"))
  }
