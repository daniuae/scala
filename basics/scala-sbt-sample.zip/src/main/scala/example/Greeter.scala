package example

object Greeter:
  def greet(name: String): String = s"Hello, $name"
