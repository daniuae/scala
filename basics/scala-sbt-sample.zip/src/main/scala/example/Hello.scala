package example

@main def hello(name: String = "World"): Unit =
  println(s"Hello, $name! Running Scala ${util.Properties.versionNumberString}")
