package com.vngrs.etl

/**
  * A Hello World Application
  */
object Application {
  /**
    * Hello World application entry point
    *
    * @param args App Arguments
    */
  def main(args: Array[String]): Unit = {
    print("Hello WORLD!")
  }
}
