package example

// HelloWorld.scala
//object HelloWorld
//Defines a singleton object (no static keyword in Scala — everything lives in objects).
//def main(args: Array[String]): Unit
object HelloWorld {
  def main(args: Array[String]): Unit = { //def main(args: Array[String]): Unit
    println("Hello, Scala!")
  }
}
//Entry point of a Scala program (like public static void main in Java).

//  println("Hello, Scala!")

//Prints text to the console.
//  Unit
//Equivalent to void in Java — means “no return value.”

