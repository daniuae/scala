package example
/*
A Higher-Order Function (HOF) is a function that does
at least one of the following:
* Takes another function as a parameter, or
Returns a function as a result.
* This is a key concept in functional programming, allowing
more reusable, modular, and expressive code.*/

object HigherOrderExample {
  // A higher-order function that takes another function as parameter
  def applyFunction(f: Int => Int, x: Int): Int = {
    f(x)
  }

  def main(args: Array[String]): Unit = {
    //Function applyFunction
    val result = applyFunction(x => x * x, 5)
    println(result) // Output: 25
  }
}