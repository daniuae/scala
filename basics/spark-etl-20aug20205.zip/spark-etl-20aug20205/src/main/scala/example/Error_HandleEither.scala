package example

object OptionExampleEither {
  def validateAge(age: Int): Either[String, Int] = {
    if (age >= 18) Right(age)
    else Left("Age must be 18 or above")
  }

  def main(args: Array[String]): Unit = {
    val result1 = validateAge(25)
    val result2 = validateAge(15)

    result1 match {
      case Right(v) => println(s"Valid age: $v")
      case Left(err) => println(s"Error: $err")
    }

    result2 match {
      case Right(v) => println(s"Valid age: $v")
      case Left(err) => println(s"Error: $err")
    }
  }
}
