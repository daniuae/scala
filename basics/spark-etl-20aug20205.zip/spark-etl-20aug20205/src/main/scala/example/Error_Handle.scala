package example
//Option is used when a value might be missing (nullable).
//It can be:
//Some(value) — represents a valid value
//None — represents absence of value (like null but type-safe)

object OptionExample {
  def safeDivide(a: Int, b: Int): Option[Double] = {
    if (b == 0) None else Some(a.toDouble / b) //Some is used here // None
  }

  def main(args: Array[String]): Unit = {
    val result1 = safeDivide(10, 2)
    val result2 = safeDivide(10, 0)

    println(result1.getOrElse("Division by zero"))
    println(result2.getOrElse("Division by zero"))
  }
}
