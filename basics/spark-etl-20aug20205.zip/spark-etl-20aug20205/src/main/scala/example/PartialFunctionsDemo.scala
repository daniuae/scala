package example
/*
A partial function in Scala is a function that is only
defined for a specific subset of possible input values,
rather than all values of its input type. These functions
are built from the PartialFunction[A, B] trait, where A is
the input type and B is the output type. Unlike total
functions, partial functions may not return a result
for every input, and their domain is explicitly limited.
 */
@main def partialFunction(): Unit =
  val doubledOdds: PartialFunction[Int, Int] = {
    case i if i % 2 == 1 => i * 2
  }
  doubledOdds.isDefinedAt(3) // true
  doubledOdds.isDefinedAt(4) // false
  doubledOdds(3) // 6
// doubledOdds(4) would throw MatchError


