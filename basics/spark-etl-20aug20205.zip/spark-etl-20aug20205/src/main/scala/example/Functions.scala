package example

@main def functionDemo(): Unit =
  def add(a: Int, b: Int): Int = a + b
  def greet(name: String = "Guest"): String = s"Hello, $name!"

  println(add(10, 20))
  println(greet("Sneha"))
  println(greet()) // uses default
