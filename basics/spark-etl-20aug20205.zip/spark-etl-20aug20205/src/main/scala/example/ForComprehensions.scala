package example
/*
* For-comprehensions in Scala provide a concise,
* expressive way to iterate, filter, and transform
* collections or monads (like Option, Either, or Future).
* They are more powerful than traditional for-loops
* because they support generators, filters, and
* definitions within the loop, and they
* produce collections or values via the yield keyword.*/
@main def ForComprehension(): Unit =
  for {
    x <- List(1, 2, 3) // Generator
    if x % 2 == 1 // Filter
    square = x * x // Definition
  } yield square // List(1, 9)

  val names = List("Sam", "Sara", "Paul")
  val filtered = for {
    name <- names
    if name.startsWith("S")
  } yield name.toUpperCase         // Result: List("SAM", "SARA")

    println(names.head)
    println(filtered)