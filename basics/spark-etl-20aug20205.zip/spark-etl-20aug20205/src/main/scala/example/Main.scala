package example

@main def main(args: String*): Unit =
  println(s"Hello ${args.mkString}")
  val name: String = "Kapil"
  var age: Int = 25

  println(s"My name is $name and I am $age years old")

  age += 1
  println(s"Next year, I will be $age")

  // Type inference
  val salary = 50000.50  // Double
  println(s"Salary: $salary")
