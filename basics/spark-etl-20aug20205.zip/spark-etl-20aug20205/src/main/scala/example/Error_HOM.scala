package example
import scala.util.{Try, Success, Failure}
object OptionExampleHOM {


  def main(args: Array[String]): Unit = {
    val t = Try(10 / 0)

    t.foreach(println) // Nothing printed (Failure)
    println(t.isSuccess) // false
    println(t.isFailure) // true

    // Recover example
    val handled = t.recover {
      case _: ArithmeticException => 0
    }
    println(handled.get) // 0
  }
}
