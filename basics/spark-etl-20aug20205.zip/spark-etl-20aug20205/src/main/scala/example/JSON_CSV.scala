package example

import scala.io.Source
import java.io.PrintWriter
import ujson._

object JsonExample extends App {
  val jsonStr = Source.fromFile("customers.json").mkString
  val data = ujson.read(jsonStr)

  val transformed = data.arr.map(obj => obj("name").str.toUpperCase)
  val writer = new PrintWriter("output.json")
  writer.write(ujson.write(transformed, indent = 2))
  writer.close()
}
