package example
/*
Currying in Scala is a technique where a function with multiple arguments is
transformed into a sequence of functions, each taking a single argument.
This concept, named after logician Haskell Curry, is widely used in functional
programming and is natively supported by Scala, providing benefits like modularity,
reusability, and simplified function composition.

Currying converts a function that takes multiple parameters into a chain of functions,
each taking exactly one parameter.
*/
@main def CurryingDemo(): Unit =
  def add(a: Int, b: Int): Int = a + b // Normal function
  def addCurried(a: Int)(b: Int): Int = a + b // Curried function
  println(addCurried(2)(3)) // Prints 5


/*
*Advantages of Currying
Partial Application: Enables pre-fixing some arguments to create specialized functions.
Reusability: Curried functions help modularize and reuse logic.
Simplifies Composition: Makes chaining and composing functions easier, aligning with functional paradigms.
Enhanced Type Inference: Helps Scala’s static type system provide better type hints.
* */

