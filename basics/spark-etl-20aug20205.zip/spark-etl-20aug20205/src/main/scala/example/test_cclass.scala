package example

case class test_cclass()
case class Person(name: String, age: Int)


object IndianNamesDemo extends App {
  val p1 = Person("Aarav", 25)
  val p2 = Person("Diya", 30)
  val p3 = p1.copy(name = "Kavya")

  println(p1)        // Person(Aarav,25)
  println(p2)        // Person(Diya,30)
  println(p3)        // Person(Kavya,25)
}
