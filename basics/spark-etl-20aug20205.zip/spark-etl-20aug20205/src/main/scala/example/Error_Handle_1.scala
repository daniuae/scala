package example
//Why use Option?
//   Avoids NullPointerException
//   Makes the absence of a value explicit

object OptionExample1 {

  def main(args: Array[String]): Unit = {
    val maybeName: Option[String] = Some("dani")
    val formatted = maybeName.map(_.capitalize)
    println(formatted.getOrElse("Unknown")) // Dani

    val noneName: Option[String] = None
    println(noneName.map(_.capitalize).getOrElse("No Name")) // No Name

  }
}
