package example

import scala.util.{Try, Success, Failure}
import scala.io.Source

object OptionExample2 {
  def readFile(path: String): Try[String] = Try {
    Source.fromFile(path).getLines().mkString("\n")
  }

  def main(args: Array[String]): Unit = {
    val result = readFile("data/input.txt")

    result match {
      case Success(content) => println("File contents:\n" + content)
      case Failure(ex) => println(s"Error: ${ex.getMessage}")
    }
  }
}
