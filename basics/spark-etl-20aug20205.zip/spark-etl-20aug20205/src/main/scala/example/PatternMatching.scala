package example
/*
Case classes in Scala are a special type of class designed primarily
for modeling immutable data with concise syntax and several built-in
features that aid in data handling, comparison, and pattern matching.
*/

@main def caseClassDemo(): Unit =
  case class Employee(id: Int, name: String, dept: String)

  val emp1 = Employee(1, "Tharun", "IT")
  val emp2 = emp1.copy(name = "Dev")

  println(emp1)
  println(emp2)

  emp2 match
    case Employee(_, "Dev", _) => println("Found Dev")
    case _ => println("Unknown Employee")

