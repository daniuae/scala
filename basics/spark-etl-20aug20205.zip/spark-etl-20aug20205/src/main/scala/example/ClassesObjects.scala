package example

class Vehicle(val brand: String):
  def drive(): Unit = println(s"$brand vehicle is driving")

class Car(brand: String, val model: String) extends Vehicle(brand):
  override def drive(): Unit =
    println(s"Car $brand $model is driving fast!")

@main def inheritanceDemo(): Unit =
  val car = Car("Tesla", "Model S")
  car.drive()
