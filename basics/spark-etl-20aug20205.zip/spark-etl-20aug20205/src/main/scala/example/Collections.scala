package example

@main def collectionsDemo(): Unit =
  val fruits = List("Apple", "Banana", "Mango")
  val prices = Map("Apple" -> 100, "Banana" -> 40)
  val uniqueNums = Set(1, 2, 2, 3)

  println(fruits.head)
  println(prices("Apple"))
  println(uniqueNums)

  fruits.foreach(f => println(s"Fruit: $f"))
