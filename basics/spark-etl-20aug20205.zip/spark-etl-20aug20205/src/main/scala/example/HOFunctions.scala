package example

/*Higher-Order Functions (HOFs) in Scala are functions
that either take other functions as parameters or
return a function as a result. This capability stems
from Scala treating functions as first-class values, allowing
them to be passed around and manipulated just like other
data types.*/

