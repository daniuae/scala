object HigherOrderExample {
  def compute(x: Int, f: Int => Int): Int = f(x)

  def main(args: Array[String]): Unit = {
    println(compute(5, x => x * x))
  }
}