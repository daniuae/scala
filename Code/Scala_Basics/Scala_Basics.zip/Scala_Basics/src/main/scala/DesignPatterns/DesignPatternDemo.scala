package DesignPatterns

// Scala Design Patterns — Compact examples for common patterns
// Author: ChatGPT
// Each pattern is in its own object with a small demo `run()` method.

object DesignPatterns {

  // ------------------ Creational ------------------

  // 1) Singleton (Scala's object is a singleton)
  object AppConfig {
    var env: String = "dev"
    def info() = s"Environment: $env"
  }

  // 2) Factory Method
  trait Product { def name: String }
  class ConcreteProductA extends Product { val name = "ProductA" }
  class ConcreteProductB extends Product { val name = "ProductB" }
  trait Creator { def create(tpe: String): Product }
  class ConcreteCreator extends Creator {
    def create(tpe: String) = if (tpe=="A") new ConcreteProductA else new ConcreteProductB
  }

  // 3) Abstract Factory
  trait GUIFactory { def button: Button; def checkbox: Checkbox }
  trait Button { def paint(): String }
  trait Checkbox { def paint(): String }
  class WinButton extends Button { def paint() = "Windows Button" }
  class MacButton extends Button { def paint() = "Mac Button" }
  class WinCheckbox extends Checkbox { def paint() = "Windows Checkbox" }
  class MacCheckbox extends Checkbox { def paint() = "Mac Checkbox" }
  class WinFactory extends GUIFactory { val button = new WinButton; val checkbox = new WinCheckbox }
  class MacFactory extends GUIFactory { val button = new MacButton; val checkbox = new MacCheckbox }

  // 4) Builder
  case class Pizza(size: Int, cheese: Boolean, pepperoni: Boolean, bacon: Boolean)
  class PizzaBuilder {
    private var size = 12
    private var cheese = false
    private var pepperoni = false
    private var bacon = false
    def setSize(s:Int) = { size=s; this }
    def addCheese() = { cheese=true; this }
    def addPepperoni() = { pepperoni=true; this }
    def addBacon() = { bacon=true; this }
    def build() = Pizza(size, cheese, pepperoni, bacon)
  }

  // 5) Prototype (clone)
  trait Prototype { def cloneProto(): Prototype }
  case class Point(x:Int,y:Int) extends Prototype { def cloneProto() = this.copy() }

  // ------------------ Structural ------------------

  // 6) Adapter
  class OldAPI { def specificRequest() = "Old API result" }
  trait NewAPI { def request(): String }
  class Adapter(old: OldAPI) extends NewAPI { def request() = old.specificRequest() }

  // 7) Bridge
  trait Renderer { def renderCircle(radius:Int): String }
  class VectorRenderer extends Renderer { def renderCircle(r:Int) = s"Vector circle of $r" }
  class RasterRenderer extends Renderer { def renderCircle(r:Int) = s"Raster circle of $r pixels" }
  class Circle(var radius:Int, renderer: Renderer) { def draw() = renderer.renderCircle(radius) }

  // 8) Composite
  trait Graphic { def draw(): String; def add(g:Graphic): Unit = throw new UnsupportedOperationException }
  class Dot(val name:String) extends Graphic { def draw() = s"Dot($name)" }
  class Compound extends Graphic {
    private var children = List.empty[Graphic]
    def draw() = children.map(_.draw()).mkString("\n")
    override def add(g:Graphic) = children ::= g
  }

  // 9) Decorator
  trait Notifier { def send(msg:String): String }
  class EmailNotifier extends Notifier { def send(msg:String) = s"Email: $msg" }
  class SMSDecorator(inner: Notifier) extends Notifier { def send(msg:String) = inner.send(msg) + s" + SMS: $msg" }

  // 10) Facade
  class SubA { def a() = "A" }
  class SubB { def b() = "B" }
  class Facade { val a=new SubA; val b=new SubB; def doWork() = a.a() + b.b() }

  // 11) Flyweight (simple cache)
  class Icon(val name:String)
  object IconFactory { private val cache = scala.collection.mutable.Map.empty[String, Icon]; def get(name:String) = cache.getOrElseUpdate(name, new Icon(name)) }

  // 12) Proxy
  trait Image { def display(): String }
  class RealImage(path:String) extends Image { def display() = s"Displaying $path" }
  class ImageProxy(path:String) extends Image {
    private var real: Option[RealImage] = None
    def display() = { if(real.isEmpty) real = Some(new RealImage(path)); real.get.display() }
  }

  // ------------------ Behavioral ------------------

  // 13) Strategy
  trait SortStrategy { def sort(data: List[Int]): List[Int] }
  class QuickSort extends SortStrategy { def sort(data:List[Int]) = data.sorted }
  class BubbleSort extends SortStrategy { def sort(data:List[Int]) = data.reverse }
  class Sorter(var strategy: SortStrategy) { def sort(data:List[Int]) = strategy.sort(data) }

  // 14) Observer
  trait Observer { def update(msg:String): Unit }
  trait Subject { def register(o:Observer): Unit; def unregister(o:Observer): Unit; def notifyAll(msg:String): Unit }
  class SimpleSubject extends Subject {
    private val obs = scala.collection.mutable.ListBuffer.empty[Observer]
    def register(o:Observer)= obs += o
    def unregister(o:Observer)= obs -= o
    def notifyAll(msg:String)= obs.foreach(_.update(msg))
  }

  // 15) Command
  trait Command { def execute(): Unit }
  class Light { private var on=false; def onCmd() = { on=true; println("Light on") }; def offCmd() = { on=false; println("Light off") } }
  class LightOnCommand(light: Light) extends Command { def execute() = light.onCmd() }
  class LightOffCommand(light: Light) extends Command { def execute() = light.offCmd() }

  // 16) Iterator (custom)
  class MyCollection[T](items: List[T]) { def iterator = items.iterator }

  // 17) Mediator
  trait Mediator { def notify(sender: Colleague, event: String): Unit }
  abstract class Colleague(val mediator: Mediator)
  class ConcreteMediator extends Mediator {
    var c1: Option[ConcreteColleague1] = None
    var c2: Option[ConcreteColleague2] = None
    def notify(sender: Colleague, event: String) = if(sender == c1.orNull) c2.foreach(_.receive(event)) else c1.foreach(_.receive(event))
  }
  class ConcreteColleague1(m: Mediator) extends Colleague(m) { def send(e:String) = mediator.notify(this, e); def receive(e:String) = println(s"C1 got $e") }
  class ConcreteColleague2(m: Mediator) extends Colleague(m) { def send(e:String) = mediator.notify(this, e); def receive(e:String) = println(s"C2 got $e") }

  // 18) Memento
  case class Memento(state:String)
  class Originator(var state:String) { def save() = Memento(state); def restore(m:Memento) = state = m.state }
  class Caretaker { private var history = List.empty[Memento]; def push(m:Memento)= history ::= m; def pop() = { val h = history.head; history = history.tail; h } }

  // 19) State
  trait State { def handle(): String }
  class Started extends State { def handle() = "Started" }
  class Stopped extends State { def handle() = "Stopped" }
  class Machine(var state: State) { def request() = state.handle() }

  // 20) Template Method
  abstract class Game { def initialize(): Unit; def startPlay(): Unit; def endPlay(): Unit; final def play() = { initialize(); startPlay(); endPlay() } }
  class Football extends Game { def initialize()=println("Football init"); def startPlay()=println("Football play"); def endPlay()=println("Football end") }

  // 21) Visitor (simple)
  trait Visitor { def visitA(a: ElementA): Unit; def visitB(b: ElementB): Unit }
  trait Element { def accept(v: Visitor): Unit }
  class ElementA extends Element { def accept(v:Visitor) = v.visitA(this); def opA() = "A" }
  class ElementB extends Element { def accept(v:Visitor) = v.visitB(this); def opB() = "B" }
  class ConcreteVisitor extends Visitor { def visitA(a:ElementA)=println(a.opA()); def visitB(b:ElementB)=println(b.opB()) }

  // 22) Chain of Responsibility
  abstract class Handler { var next: Option[Handler] = None; def handle(req:Int): Unit = next.foreach(_.handle(req)) }
  class ConcreteHandler1 extends Handler { override def handle(req:Int) = if(req<10) println("handled by 1") else super.handle(req) }
  class ConcreteHandler2 extends Handler { override def handle(req:Int) = if(req<20) println("handled by 2") else super.handle(req) }

  // ------------------ Demo runner ------------------
  def runAll(): Unit = {
    println("Singleton:" + AppConfig.info())
    val pc = new ConcreteCreator(); println("Factory:" + pc.create("A").name)
    val fac: GUIFactory = new WinFactory(); println("AbstractFactory:" + fac.button.paint())
    println("Builder:" + (new PizzaBuilder).setSize(16).addCheese().addBacon().build())
    println("Prototype:" + Point(1,2).cloneProto())
    println("Adapter:" + (new Adapter(new OldAPI)).request())
    println("Bridge:" + new Circle(5, new RasterRenderer).draw())
    val comp = new Compound(); comp.add(new Dot("d1")); comp.add(new Dot("d2")); println("Composite:\n" + comp.draw())
    println("Decorator:" + new SMSDecorator(new EmailNotifier()).send("hello"))
    println("Facade:" + new Facade().doWork())
    println("Flyweight:" + (IconFactory.get("x").name))
    val img = new ImageProxy("/tmp/p.png"); println(img.display())
    val sorter = new Sorter(new QuickSort()); println("Strategy:" + sorter.sort(List(3,1,2)))
    val subj = new SimpleSubject(); val o = new Observer { def update(m:String)=println(s"Obs got $m") }; subj.register(o); subj.notifyAll("hi")
    val light = new Light(); val on = new LightOnCommand(light); on.execute()
    val col = new MyCollection(List(1,2,3)); println("Iterator:" + col.iterator.mkString(","))
    val med = new ConcreteMediator(); val c1 = new ConcreteColleague1(med); val c2 = new ConcreteColleague2(med); med.c1 = Some(c1); med.c2 = Some(c2); c1.send("ping")
    val orig = new Originator("v1"); val care = new Caretaker(); care.push(orig.save()); orig.state = "v2"; orig.restore(care.pop()); println("Memento:" + orig.state)
    val m = new Machine(new Started()); println("State:" + m.request())
    new Football().play()
    val visitor = new ConcreteVisitor(); new ElementA().accept(visitor); new ElementB().accept(visitor)
    val h1 = new ConcreteHandler1(); val h2 = new ConcreteHandler2(); h1.next = Some(h2); h1.handle(5); h1.handle(15)
  }

}

// Run demos
object RunDesignPatterns { def main(args:Array[String]) = DesignPatterns.runAll() }
