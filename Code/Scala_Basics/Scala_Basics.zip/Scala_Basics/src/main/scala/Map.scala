object MapExample {
  def main(args: Array[String]): Unit = {
    val data = Map("Tamil" -> 85, "English" -> 90)
    println(data("Tamil"))
  }
}
