object EvenOdd {
  def main(args: Array[String]): Unit = {
    val num = 15
    if (num % 2 == 0) println("Even") else println("Odd")
  }
}
