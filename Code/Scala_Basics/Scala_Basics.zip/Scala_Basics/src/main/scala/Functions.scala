object FunctionExample {
  def add(a: Int, b: Int): Int = a + b

  def main(args: Array[String]): Unit = {
    println(add(10, 20))
  }
}
