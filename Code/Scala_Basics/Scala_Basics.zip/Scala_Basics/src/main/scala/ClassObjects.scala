class Person(name: String, age: Int) {
  def details(): String = s"Name: $name, Age: $age"
}

object PersonApp {
  def main(args: Array[String]): Unit = {
    val p = new Person("Dani", 30)
    println(p.details())
  }
}
