object ListExample {
  def main(args: Array[String]): Unit = {
    val nums = List(1, 2, 3, 4, 5)
    println(nums.head)
    println(nums.tail)
    println(nums.sum)
  }
}
