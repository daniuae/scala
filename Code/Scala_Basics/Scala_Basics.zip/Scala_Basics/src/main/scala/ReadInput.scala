object ReadInput {
  def main(args: Array[String]): Unit = {
    print("Enter something: ")
    val input = scala.io.StdIn.readLine()
    println("You entered: " + input)
  }
}
