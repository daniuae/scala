object PatternMatch {
  def check(x: Any): String = x match {
    case 0 => "Zero"
    case i: Int if i > 0 => "Positive"
    case i: Int if i < 0 => "Negative"
    case _ => "Unknown"
  }

  def main(args: Array[String]): Unit = {
    println(check(-11))
  }
}
