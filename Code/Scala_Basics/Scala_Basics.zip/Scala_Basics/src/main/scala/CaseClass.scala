case class Employee(id: Int, name: String)

object CaseClassExample {
  def main(args: Array[String]): Unit = {
    val e = Employee(1, "Yuvan")
    println(e.name)
  }
}
