object Largest {
  def main(args: Array[String]): Unit = {
    val a = 12
    val b = 5
    val c = 30
    val max = if (a > b && a > c) a else if (b > c) b else c
    println(s"Largest: $max")
  }
}

